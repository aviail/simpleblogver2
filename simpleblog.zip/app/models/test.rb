class Test < ApplicationRecord
end
