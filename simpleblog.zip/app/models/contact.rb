class Contact < ApplicationRecord
end
