class Pool < ApplicationRecord
end
