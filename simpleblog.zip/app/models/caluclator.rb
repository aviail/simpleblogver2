class Caluclator < ApplicationRecord
end
