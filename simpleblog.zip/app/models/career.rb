class Career < ApplicationRecord
end
