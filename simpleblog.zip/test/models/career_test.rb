require "test_helper"

class CareerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
